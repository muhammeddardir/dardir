<?php

    $dsn  = 'mysql:host=localhost;dbname=task'; //data source name--> prefix sql 
    $user = 'root'; //The user to connect
    $pass = '1299';
    $option = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAME UTF8',


    );
    try{
        $conn = new PDO($dsn,$user,$pass); //start connection with PDO Class
    }
    catch(PDOException $e){
        
        echo "faild" . $e->getMessage();
    }






