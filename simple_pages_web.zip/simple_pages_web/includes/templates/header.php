<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>admin</title>
    <link rel="stylesheet" href="<?php echo $css; ?>fontawesome.min.css" />
    <link rel="stylesheet" href="<?php echo $css; ?>bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $css; ?>backend.css" />
    <link rel="stylesheet" href="<?php echo $css; ?>conact.css" />
    
    
</head>

<body>
<style>

</style>

<div class="header">
  <img src = "layout/images/task.jpg">
</div> 
