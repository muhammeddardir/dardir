<!-- Start Footer -->
        
<div class="footer">
            <div class="container">
                <span class="copyright">&copy; 2020 COPYRIGHT ^_^ </span>
                <span class="design">DESIGNED BY Dardir</span>
            </div>
        </div>
        
        <!-- End Footer -->
<script src = "<?php echo $js; ?>bootstrap.min.js"></script>
<script src = "<?php echo $js; ?>jquery3.5.1.min.js"></script>
<script src = "<?php echo $js; ?>backend.js"></script>
</body>
</html>