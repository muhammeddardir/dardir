
<div class="topnav">
  <a class="active" href="home.php">Home</a>
  <a href="upload.php">upload</a>
  <a href="contact.php">Contact</a>
  <a class = "logout" href="logout.php">Logout</a>
</div> 


