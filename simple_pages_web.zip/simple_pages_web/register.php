<?php 
   session_start(); //put it in all page
   if(isset($_SESSION['username'])){ // if find session redierct me to home page
    header('location : home.php');

   }
   $noNavBar = '';
   include 'init.php';
?>
<?php
$servername = "localhost";
$username = "root";
$password = "1299";
$dbname = "task";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $name = $_POST['username'];
  $email = $_POST['email'];
  $pass = $_POST['password'];
  $gender = $_POST['gender'];

  $sql = "INSERT INTO users (Name,Email,password,gender) VALUES ('$name', '$email',$pass,'$gender')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>
<center>  <h4 class="text-center">Register</h4> </center>
<form class="Register" method="post" action = "<?php echo $_SERVER['PHP_SELF']?>">
   <label for="name">Name</label>
    <input type="text" name="username" class="form-control" required /><br /> 
    <label for="email">Email</label>
    <input type="email" name="email" class="form-control" required /><br /> 
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control" required /> <br /> 
    <label for="gender">Gender</label> <br />
    <input type="radio" name="gender" value="m" required />Male <br />
    <input type="radio" name="gender" value="f" required />Female <br >
    <? header('location: index.php');?>
    <input type="submit" class="btn btn-primary btn-block" name="submit" value="Register" >
    <a class = "login" class="text-center" href ="index.php">Login</a>
</form> 
<?php include $tpl . 'footer.php'; ?>