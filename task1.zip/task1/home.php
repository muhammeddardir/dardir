<?php
include "init.php";
?>

    
<div>
<br>
<br>
<br>
<br>
<img src = "layout/images/1.jpg"/>
<br>
<div>
<br>
<br>
<br>
<br>
<br>

<?php include $tpl . 'footer.php'; ?>