<?php

    $dsn  = 'mysql:host=localhost;dbname=task'; //data source name--> prefix sql 
    $user = 'root'; //The user to connect
    $pass = '';
    $option = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAME UTF8',


    );
    try{
        $db = new PDO($dsn,$user,$pass); //start connection with PDO Class
        $db = setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        echo "you are connecting";
    }
    catch(PDOException $e){
        
        echo "faild" . $e->getMessage();
    }






