<?php

//Routes

$tpl   = 'includes/templates/';       //Templates Directory
$css   = 'layout/css/' ;             //Css Directory 
$js    = 'layout/js/'  ;            //js Directory
$langs = 'includes/languages/' ;  //language Directory and must be first include file to know other lang

//Includes The Important File

include $langs . 'en.php'; 
include $tpl . 'header.php';

// Include The Navbar in pages  Not contain $noNavBar Variable

if(!isset($noNavBar)){
    include $tpl . 'navbar.php'
    ;}


