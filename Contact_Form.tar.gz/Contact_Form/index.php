<?php

// check Method Request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	//Assign Variable
if (isset($UserName,$Email,$Phone,$Message)) {
}
	$UserName = filter_var($_POST['UserName'],FILTER_SANITIZE_STRING);
	$Email 	  = filter_var($_POST['Email'],FILTER_SANITIZE_EMAIL);
	$Phone 	  = filter_var($_POST['Phone'],FILTER_SANITIZE_NUMBER_INT);
	$msg      = filter_var($_POST['Message'],FILTER_SANITIZE_STRING);

	//Array of Errors
	$form_errors = array();
		
		if (strlen($UserName) <= 4){$form_errors[] = "Your Name Must Be More Than 4 char";}
		if (strlen($Email) <= 10) {$form_errors[] = "Your Email Must Be More Than 10 char";}
		if (strlen($Phone) < 11) {$form_errors[] = "Your Phone Must Be 11 char";}
		if (strlen($msg) <= 10){$form_errors[] = "Your Message Must Be More Than 10 char";}



}
	//send E-mail If No Error
	@$header = 'From : ' . $Email . '\r\n';
	
	if (empty($form_errors))
	{
		@mail('muhammed@gmail.com','Contact Me',$msg,$header);
	$UserName = '';
	$Email 	  = '';
	$Phone 	  = '';
	$msg      = '';

	$success = "<div class ='alert alert-success'>success Sending Email</div>";
	}


?>
<!DCOTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta meta http-equiv= x-ua-compatible content= ie=edge>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Yusei+Magic&display=swap"> 
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/all.css">
</head>
<body>
	<!-- Start Form-->
	<div class="container">

		<h2 class="text-center">Contact Me</h2>
		<form class="Contact_Form" method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
			<!-- ERRor TEST -->
		<?php if (!empty($form_errors)) { ?>

			<div class="alert alert-warning alert-dismissible fade show alert-danger" role="alert">
  					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    					<span aria-hidden="true">&times;</span>
  					</button>
  			<?php
				if (isset($form_errors)) {
					foreach ($form_errors as $error) {
					echo  $error . "<br/>";
					}
				} 
			?>

			</div>
		<?php } ?>
		<?php if(empty($success)){echo $success;} ?>
		<!-- ERRor TEST -->
			<div class="form-group"> <!--form-group -> Make element in one div  -->
				<input 
					   	class="form-control" 
					   	type="text" 
					   	placeholder="Enter UserName" 
					   	name="UserName"
					   	value="<?php if(isset($UserName)){echo $UserName;}?>" 
					   	aria-label="Disabled input example"
					   	required >
				<i class="fa fa-users fa-fw"></i>
				<span class="astrixs">*</span>
			</div>
			<div class="form-group">
			<input 
				   	class="form-control"
				   	type="email"
				   	name="Email" 
				   	placeholder="Enter Your E-mail"
				   	value="<?php if(isset($Email)){echo $Email;}?>"  
				   	aria-label="Disabled input example"
				   	required>
			<i class="fa fa-envelope fa-fw"></i>
			<span class="astrixs">*</span>
			</div>
			<input 
					class="form-control" 
					type="text" 
					placeholder="Enter Your Phone Number" 
					name="Phone"
					value="<?php if(isset($Phone)){echo $Phone;}?>" 
					aria-label="Disabled input example"
					required >
			<i class="fa fa-phone fa-fw"></i>
			<textarea 
					name="Message" 
					class="form-control"
					placeholder="Enter Your Message" required> <?php if(isset($msg)){echo $msg;} ?></textarea>
			<button 
					type="submit" 
					class="btn btn-primary submit" >send
			</button>

			<i class="fa fa-paper-plane fa-fw send-icon"></i>
		</form>
	</div>
	<!-- End Form-->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
</body>
</html>